export NODE_ENV='development'
export PORT=3000
export SECRET='secret' # para mayor seguridad puedes cambiar esto por el secreto de tu preferencia
export MONGODB_URI='mongodb+srv://introadb:introadb1234@cluster0.ijbvb.mongodb.net/AdoptaPet?retryWrites=true&w=majority'